import S3 from "react-s3";
import React, { useState } from "react";

function App() {
  Buffer.from('anything','base64');

	const [file, setFile] = useState(null);
	const [text, setText] = useState("default");

	function handleClickSubmit() {
		const config = {
			bucketName: "fovus-test-v",
			region: "us-east-1",
			accessKeyId: "AKIA2Q35L3BTGZVWFKUO",
			secretAccessKey: "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",
		};

		S3.uploadFile(text, config)
			.then((data) => {
				console.log(data.location);
				alert("File uploaded successfully!");
			})
			.catch((err) => {
				console.error(err);
				alert("Error uploading file. Please try again.");
			});
	}

	function handleInputChange(event) {
		console.log(event.target.files);
		setFile(event.target.files[0]);
	}

	function handleTextChange(e) {
		setText(e.target.value);
	}

	return (
		<div className="App">
			<div>
				<div style={{ display: "flex", alignItems: "center" }}>
					<p>Text Input:&nbsp;&nbsp;</p>
					<input type="text" onChange={handleTextChange} />
				</div>

				<div style={{ display: "flex", alignItems: "center" }}>
					<p>File Input:&nbsp;&nbsp;</p>
					<input type="file" onChange={handleInputChange} />
				</div>

				<button onClick={handleClickSubmit}>Submit</button>
			</div>
		</div>
	);
}

export default App;
